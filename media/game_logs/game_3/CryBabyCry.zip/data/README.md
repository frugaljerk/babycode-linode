In Baby Invasion, the player controls a dady ship that appears
at the bottom center of the screen. The player can move the daddy right and left using the arrow keys and shoot pacifier using the spacebar. When the game begins, a fleet of babies fills the sky and moves across and down the screen. The player shoots and sooth the babies. If the player shoots all the babies, a new fleet appears that moves faster than the previous fleet. If any baby hits the player’s daddy ship or reaches the bottom of the screen, the player loses a ship. If the player loses three ships, the game ends.

1. Download the file and click on Baby_invasion.exe to play.

2. Presss 'q' button to exist anytime.

3. Click the player name button, type in your name and then press 'ENTER'.

4. Click 'Play' Button to start.

5. Use 'Left Arrow' and 'Right Arrow' Button to control Daddy. Press 'Space button' to shoot pacifier. Press 'v' to summon Mommy.

6. Shoot down crying babies to stop them from reaching daddy's base. See how many levels and points you can get to.

7. Enjoy and thank you for playing. 